//
//  ContentView.swift
//  work_3
//
//  Created by Stanislav Belsky on 25.03.2020.
//  Copyright © 2020 Stanislav Belsky. All rights reserved.
//

import SwiftUI
import Combine

struct ContentView: View {
    @ObservedObject var viewModel = GameListViewModel()
    
    var body: some View {
        NavigationView {
            Group {
                VStack {
                    SearchBar(searchText: $viewModel.searchTerm,
                              showCancelButton: $viewModel.showCancelButton)
                    List(viewModel.movies, id: \.title) { game in
                        Text(verbatim: game.title)
                    }
                }
            }
            .navigationBarTitle(Text("Movies"))
        }
    }
}


struct SearchBar: View {
    
    @Binding var searchText: String
    @Binding var showCancelButton: Bool
    
    var body: some View{
        HStack {
            HStack {
                
                //                Image(systemName: "magnifyingglass")
                
                TextField("search", text: $searchText, onEditingChanged: { isEditing in
                    self.showCancelButton = true
                }, onCommit: {
                    print("onCommit")
                }).foregroundColor(.primary)
                
                Button(action: {
                    self.searchText = ""
                }) {
                    Image(systemName: "xmark.circle.fill").opacity(searchText == "" ? 0 : 1)
                }
            }
            .padding(EdgeInsets(top: 16, leading: 6, bottom: 16, trailing: 6))
            .foregroundColor(.secondary)
            .background(Color(.secondarySystemBackground))
            .cornerRadius(10.0)
            
            if showCancelButton  {
                Button("Cancel") {
                    UIApplication.shared.endEditing(true)
                    self.searchText = ""
                    self.showCancelButton = false
                }
                .foregroundColor(Color(.systemBlue))
            }
        }
        .padding(.horizontal)
        .navigationBarHidden(showCancelButton)
        .animation(.linear)
        
    }
    
}

final class GameListViewModel: ObservableObject {
    
    @Published var isLoading: Bool = false
    @Published var showCancelButton: Bool = true
    @Published var movies: [MovieData] = []
    
    @Published var searchTerm: String = "1"
    
    let movieService = MovieApi()
    
    private var disposeBag = Set<AnyCancellable>()
    
    init() {
        
        $isLoading.dropFirst().sink { (val) in
            print("loading", val)
        }
        .store(in: &disposeBag)
        
        $searchTerm
            .removeDuplicates()
            .debounce(for: 0.5, scheduler: DispatchQueue.main)
            .setFailureType(to: ApiError.self)
            .flatMap({ (search)  -> Future<[MovieData], ApiError> in
                DispatchQueue.main.async {
                    self.isLoading = true
                }
                return self.movieService.fetchMovies(search: search)
            })
            .handleEvents(
                receiveOutput: { _ in
                    print("receiveOutput")
                    DispatchQueue.main.async {
                        self.isLoading = false
                    }
            })
            .receive(on: DispatchQueue.main)
            .sink(receiveCompletion: {  (completion) in
               switch completion {
               case .failure(let error):
                   print(error)
               case .finished:
                   print("DONE - postUserPublisher")
               }
            }, receiveValue: { (results) in
                
                print("results", results)
                self.movies = results
            })
            .store(in: &disposeBag)
        
    }
    

    

    deinit {
        for cancell in disposeBag{
            cancell.cancel()
        }
    }
    
}

enum GameRoute {
    
    case search (searchString: String)
    
    var baseURL:URL {URL(string: "https://jsonplaceholder.typicode.com/")!}
    
    func path() -> String {
        switch self {
        case .search:
            return "posts"
        }
    }
    
    var absoluteURL:URL?{
        var url = baseURL
        url.appendPathComponent(path())
        return url
    }
}

struct Game: Codable {
    var userId: Int
    let id: Int
    let title: String
    let body: String
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            ContentView()
                .environment(\.colorScheme, .light)
            
            ContentView()
                .environment(\.colorScheme, .dark)
        }
    }
}

extension UIApplication {
    func endEditing(_ force: Bool) {
        self.windows
            .filter{$0.isKeyWindow}
            .first?
            .endEditing(force)
    }
}

struct ResignKeyboardOnDragGesture: ViewModifier {
    var gesture = DragGesture().onChanged{_ in
        UIApplication.shared.endEditing(true)
    }
    func body(content: Content) -> some View {
        content.gesture(gesture)
    }
}

extension View {
    func resignKeyboardOnDragGesture() -> some View {
        return modifier(ResignKeyboardOnDragGesture())
    }
}
