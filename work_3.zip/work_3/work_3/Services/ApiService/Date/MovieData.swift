//
//  MovieData.swift
//  work_3
//
//  Created by Stanislav Belsky on 26.03.2020.
//  Copyright © 2020 Stanislav Belsky. All rights reserved.
//

import Foundation

struct MovieData: Codable {

    let id: Int
    let mediaType: MediaType?
    let originalTitle: String
    let title: String
    let posterPath: String?
    
}
